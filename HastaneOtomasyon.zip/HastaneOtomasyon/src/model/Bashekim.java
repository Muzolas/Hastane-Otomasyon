/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;

/**
 *
 * @author Muzaffer
 */
public class Bashekim extends User {

    public Bashekim() {
       super();
    }

    public Bashekim(int Id) {
        super(Id);
    }

    public Bashekim(int Id, String tcNo, String name, String sifre, String type) {
        super(Id, tcNo, name, sifre, type);
    }
    
    public Bashekim(String tcNo, String sifre, String name) {
        super(tcNo,sifre, name);
    }
    public Bashekim(String tcNo, String sifre) {
        super(tcNo, sifre);
    }

   

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("User.txt") + 1) + ","+ this.getTcNo() + "," + this.getSifre() + "," + this.getName() + "," + "Bashekim";
        } catch (IOException ex) {
            
        }
        return null;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }
}
