/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muzaffer
 */
public final class DoktorCalismaSaati implements BaseEntity {

    private int id;

    private Doktor d;

    private String wdate;

    public DoktorCalismaSaati() {
    }

    public Doktor getD() {

        return d;
    }

    public void setD(Doktor d) {
        this.d = d;
    }

    public DoktorCalismaSaati(int id, Doktor d, String wdate) {
        this.id = id;
        this.d = d;
        this.wdate = wdate;
    }

    public DoktorCalismaSaati(Doktor d, String wdate) {
        this.d = d;
        this.wdate = wdate;
    }

    public DoktorCalismaSaati(int id) {
        this.id = id;
    }

    public String getWdate() {
        return wdate;
    }

    public void setWdate(String wdate) {
        this.wdate = wdate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("CalismaSaat.txt") + 1) + "," + this.getD().getId() + "," + this.getD().getName() + "," + wdate;
        } catch (IOException ex) {
            Logger.getLogger(DoktorCalismaSaati.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
