/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muzaffer
 */
public class DoktorCalismaSaati {
    private int id;
    private int doktorId;
    private String doktorName;
    private String wdate;

    public DoktorCalismaSaati() {
    }

    public DoktorCalismaSaati(int id) {
        this.id = id;
    }

    public int getDoktorId() {
        return doktorId;
    }

    public void setDoktorId(int doktorId) {
        this.doktorId = doktorId;
    }

    public String getDoktorName() {
        return doktorName;
    }

    public void setDoktorName(String doktorName) {
        this.doktorName = doktorName;
    }

    public String getWdate() {
        return wdate;
    }

    public void setWdate(String wdate) {
        this.wdate = wdate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("CalismaSaat.txt") + 1) + ",";
        } catch (IOException ex) {
            Logger.getLogger(DoktorCalismaSaati.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }



}
