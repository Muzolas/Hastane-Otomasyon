/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muzaffer
 */
public class Poliklinik {
    private int Id;
    private String name;

    public Poliklinik() {
    }

    public Poliklinik(String name) {
        this.name = name;
    }

    public Poliklinik(int Id) {
        this.Id = Id;
    }

    public Poliklinik(int Id, String name) {
        this.Id = Id;
        this.name = name;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("Poliklinik.txt") + 1) + "," + getName();
        } catch (IOException ex) {
            Logger.getLogger(Poliklinik.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
}
