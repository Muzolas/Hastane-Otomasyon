/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muzaffer
 */
public class Randevu {
    private int id;
    private int doktorId;
    private int hastaId;
    private String doktorName;
    private String hastaName;
    private String wdate;

    public Randevu(int id, int doktorId, int hastaId, String doktorName, String hastaName, String wdate) {
        this.id = id;
        this.doktorId = doktorId;
        this.hastaId = hastaId;
        this.doktorName = doktorName;
        this.hastaName = hastaName;
        this.wdate = wdate;
    }

    public Randevu(int id, String doktorName, String hastaName, String wdate) {
        this.id = id;
        this.doktorName = doktorName;
        this.hastaName = hastaName;
        this.wdate = wdate;
    }

    public Randevu() {
       
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDoktorId() {
        return doktorId;
    }

    public void setDoktorId(int doktorId) {
        this.doktorId = doktorId;
    }

    public int getHastaId() {
        return hastaId;
    }

    public void setHastaId(int hastaId) {
        this.hastaId = hastaId;
    }

    public String getDoktorName() {
        return doktorName;
    }

    public void setDoktorName(String doktorName) {
        this.doktorName = doktorName;
    }

    public String getHastaName() {
        return hastaName;
    }

    public void setHastaName(String hastaName) {
        this.hastaName = hastaName;
    }

    public String getWdate() {
        return wdate;
    }

    public void setWdate(String wdate) {
        this.wdate = wdate;
    }

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("Randevu.txt") + 1) + ",";
        } catch (IOException ex) {
            Logger.getLogger(Randevu.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
}
