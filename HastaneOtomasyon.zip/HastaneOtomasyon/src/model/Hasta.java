/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Muzaffer
 */
public class Hasta extends User {
    
    
    public Hasta() {
    }

    public Hasta(int Id) {
        super(Id);
    }

    public Hasta(int Id, String tcNo, String name, String sifre, String type) {
        super(Id, tcNo, name, sifre, type);
    }
    public Hasta(String tcNo, String name, String sifre) {
        super(tcNo, name, sifre);
    }

    public Hasta(String tcNo, String sifre) {
        super(tcNo, sifre);
    }

    

    /**
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        return super.equals(obj); 
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    

    
    
    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("User.txt") + 1) + ","+ this.getTcNo() + "," + this.getSifre() + "," + this.getName() + "," + "Hasta";
        } catch (IOException ex) {
            Logger.getLogger(Hasta.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    

}
