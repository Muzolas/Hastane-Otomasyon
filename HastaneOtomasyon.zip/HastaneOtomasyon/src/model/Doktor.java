/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import helper.ID_sayac;
import java.io.IOException;


/**
 *
 * @author Muzaffer
 */
public class Doktor extends User implements BaseEntity{

   
    public Doktor() {
       super();
    }

    public Doktor(int Id) {
        super(Id);
    }

    public Doktor(String name) {
        super(name);
    }

    public Doktor(int Id, String tcNo, String name, String sifre, String type) {
        super(Id, tcNo, name, sifre, type);
    }
    
    public Doktor(String tcNo, String sifre, String name) {
        super(tcNo, sifre, name);
    }
    public Doktor(String tcNo, String sifre) {
        super(tcNo, sifre);
    }

   
   

    @Override
    public String toString() {
        try {
            return (ID_sayac.idSayac("User.txt") + 1) + ","+ this.getTcNo() + "," + this.getSifre() + "," + this.getName() + "," + "Doktor";
        } catch (IOException ex) {
            
        }
        return null;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

}
