/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim.action;

import GUI.GirisGUI;
import GUI.HastaGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Muzaffer
 */
public class HastaGUI_action implements ActionListener {

    private final HastaGUI h;

    public HastaGUI_action(HastaGUI h) {
        this.h = h;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == h.getBtn_doktorSec()) {

        } else if (e.getSource() == h.getBtn_cikis()) {
            GirisGUI g = new GirisGUI();
            g.setVisible(true);
            h.dispose();
        } else {

        }

    }

}
