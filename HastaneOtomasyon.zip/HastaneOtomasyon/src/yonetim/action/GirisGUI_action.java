/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package yonetim.action;

import GUI.*;
import helper.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.logging.*;
import yonetim.*;


/**
 *
 * @author Muzaffer
 */
public class GirisGUI_action implements ActionListener {

    private final GirisGUI g;

    public GirisGUI_action(GirisGUI g) {
        this.g = g;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == g.getBtn_kayit()) {

            KayitGUI kayitGUI = new KayitGUI();
            kayitGUI.setVisible(true);
            g.dispose();

        } else if (e.getSource() == g.getBtn_hastaGiris()) {

            String tcNo = g.getTxtfld_hastaTC().getText();
            String sifre = g.getPwfld_hastaSifre().getText();

            HastaYonetim hasta = new HastaYonetim();

            if (tcNo.length() == 0 || sifre.length() == 0) {
                Helper.ShowMsg("fill");
            } else {
                try {
                    if (hasta.checkUser(tcNo, sifre) == true) {

                        HastaGUI hastaGUI = new HastaGUI(hasta.returnHasta(tcNo, sifre));
                        hastaGUI.setVisible(true);
                        g.dispose();

                    } else {
                        Helper.ShowMsg("fail");
                    }
                } catch (IOException ex) {
                    Logger.getLogger(GirisGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else if (e.getSource() == g.getBtn_doktorGiris()) {

            String tcNo = g.getTxtfld_doktorTC().getText();
            String sifre = g.getPwfld_doktorSifre().getText();

            DoktorYonetim doktor = new DoktorYonetim();

            if (tcNo.length() == 0 || sifre.length() == 0) {
                Helper.ShowMsg("fill");
            } else {
                try {
                    if (doktor.checkUser(tcNo, sifre) == true) {

                        DoktorGUI doktorGUI = new DoktorGUI(doktor.returnDoktor(tcNo, sifre));
                        doktorGUI.setVisible(true);
                        g.dispose();
                        
                    } else {
                        Helper.ShowMsg("fail");
                    }
                } catch (IOException ex) {
                    Logger.getLogger(GirisGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        } else {
            String tcNo = g.getTxtfld_basHekimTC().getText();
            String sifre = g.getPwfld_basHekimSifre().getText();

            BashekimYonetim basHekim = new BashekimYonetim();

            if (tcNo.length() == 0 || sifre.length() == 0) {
                Helper.ShowMsg("fill");
            } else {
                try {
                    if (basHekim.checkUser(tcNo, sifre) == true) {

                        BashekimGUI basHekimGUI = new BashekimGUI(basHekim.returnBashekim(tcNo,sifre));
                        basHekimGUI.setVisible(true);
                        g.dispose();

                    }else{
                        Helper.ShowMsg("fail");
                    }
                } catch (IOException ex) {
                    Logger.getLogger(GirisGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }

    }
}
