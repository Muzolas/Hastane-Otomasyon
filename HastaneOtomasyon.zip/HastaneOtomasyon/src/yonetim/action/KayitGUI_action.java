/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim.action;

import GUI.*;
import helper.Helper;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import yonetim.HastaYonetim;

/**
 *
 * @author Muzaffer
 */
public class KayitGUI_action implements ActionListener {

    private KayitGUI k;
    private HastaYonetim hy;

    public KayitGUI_action(KayitGUI k) {
        this.k = k;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == k.getBtn_kayıtOl()) {

            String tcNo = k.getTxtfld_tcNo().getText();
            String sifre = k.getPwfld_sifre().getText();
            String name = k.getTxtfld_adSoyad().getText();

            if (tcNo.length() == 0 || sifre.length() == 0 || name.length() == 0) {
                Helper.ShowMsg("fill");
            } else {
                try {
                    this.getHy().create(tcNo, sifre, name);
                    GirisGUI girisGUI = new GirisGUI();
                    k.dispose();
                } catch (IOException ex) {
                    Logger.getLogger(KayitGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        } else if (e.getSource() == k.getBtn_geriDon()) {

            GirisGUI girisGUI = new GirisGUI();
            k.dispose();
        }
    }

    public HastaYonetim getHy() {
        if (this.hy == null) {
            this.hy = new HastaYonetim();
        }
        return hy;
    }

    public void setHy(HastaYonetim hy) {
        this.hy = hy;
    }

}
