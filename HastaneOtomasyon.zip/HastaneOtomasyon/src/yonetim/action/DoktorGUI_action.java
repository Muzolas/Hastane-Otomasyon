/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim.action;

import GUI.DoktorGUI;
import GUI.GirisGUI;
import helper.Helper;
import helper.Item;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import yonetim.DoktorYonetim;

/**
 *
 * @author Muzaffer
 */
public class DoktorGUI_action implements ActionListener {

    private final DoktorGUI d;
    private SimpleDateFormat sdf;
    private DoktorYonetim dy;

    public DoktorYonetim getDy() {
        if (dy == null) {
            this.dy = new DoktorYonetim();
        }
        return dy;
    }

    public void setDy(DoktorYonetim dy) {

        this.dy = dy;
    }

    public DoktorGUI_action(DoktorGUI d) {
        this.d = d;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == d.getBtn_dateEkle()) {
            sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = "";

            try {
                date = sdf.format(d.getDate_calismaSaatleri().getDate());
            } catch (Exception e2) {
            }

            if (date.length() == 0) {
                Helper.ShowMsg("Lütfen tarih seçiniz...");

            } else {

                String time = " " + d.getCbox_time().getSelectedItem().toString();
                String selectDate = date + time;

                Item doktorItem;
                try {
                    doktorItem = (Item) d.getCbox_doktor().getSelectedItem();

                    this.getDy().addWhour(doktorItem.toString(), selectDate);

                } catch (IOException ex) {
                    Logger.getLogger(DoktorGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } else if (e.getSource() == d.getBtn_dateSil()) {

        } else if (e.getSource() == d.getBtn_cikis()) {
            GirisGUI g = new GirisGUI();
            g.setVisible(true);
            d.dispose();
        } else {

        }

    }
}
