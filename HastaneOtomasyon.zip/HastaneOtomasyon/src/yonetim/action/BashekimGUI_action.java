/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim.action;

import GUI.BashekimGUI;
import GUI.GirisGUI;
import helper.Helper;
import helper.Item;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import yonetim.BashekimYonetim;
import yonetim.DoktorYonetim;
import yonetim.PoliklinikYonetim;

/**
 *
 * @author Muzaffer
 */
public class BashekimGUI_action implements ActionListener {

    private final BashekimGUI b;
    private DoktorYonetim dy;
    private PoliklinikYonetim py;
    private BashekimYonetim by;

    public BashekimYonetim getBy() {
        if (by == null) {
            this.by = new BashekimYonetim();
        }
        return by;
    }

    public void setBy(BashekimYonetim by) {
        this.by = by;
    }

    public PoliklinikYonetim getPy() {
        if (py == null) {
            this.py = new PoliklinikYonetim();
        }
        return py;
    }

    public void setPy(PoliklinikYonetim py) {
        this.py = py;
    }

    public DoktorYonetim getDy() {
        if (dy == null) {
            this.dy = new DoktorYonetim();
        }
        return dy;
    }

    public void setDy(DoktorYonetim dy) {
        this.dy = dy;
    }

    public BashekimGUI_action(BashekimGUI b) {
        this.b = b;
    }

    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b.getBtn_doktorEkle()) {

            try {
                String tcNo = b.getTxtfld_doktorTC().getText();
                String sifre = b.getTxtfld_doktorSifre().getText();
                String name = b.getTxtfld_doktorAdsoyad().getText();
                if (getDy().checkUserK(tcNo, sifre) == true) {
                    Helper.ShowMsg("Böyle bir kullanıcı sisteme kayıtlıdır...");
                } else {
                    if (tcNo.length() == 0 || sifre.length() == 0 || name.length() == 0) {
                        Helper.ShowMsg("fill");
                    } else {

                        try {
                            this.getDy().create(tcNo, sifre, name);
                            b.getTxtfld_doktorTC().setText(null);
                            b.getTxtfld_doktorSifre().setText(null);
                            b.getTxtfld_doktorAdsoyad().setText(null);
                            b.updateDoktorModel();
                            Helper.ShowMsg("Doktor ekleme başarılı...");

                        } catch (IOException ex) {
                            java.util.logging.Logger.getLogger(BashekimGUI_action.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                        }

                    }
                }
            } catch (IOException ex) {
                Logger.getLogger(BashekimGUI_action.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (e.getSource() == b.getBtn_doktorSil()) {

            String Id = b.getTxtfld_kullanıcıID().getText();

            if (Id.length() == 0) {
                Helper.ShowMsg("fill");
            } else {

                try {
                    this.getDy().deleteUser(Id);
                    b.getTxtfld_kullanıcıID().setText(null);
                    b.updateDoktorModel();
                    Helper.ShowMsg("Doktor silme başarılı...");

                } catch (IOException ex) {
                    java.util.logging.Logger.getLogger(BashekimGUI_action.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }

            }
        } else if (e.getSource() == b.getBtn_poliklinikEkle()) {

            String name = b.getTxtfld_poliklinikAdi().getText();

            if (name.length() == 0) {
                Helper.ShowMsg("fill");
            } else {

                try {
                    this.getPy().create(name);
                    b.updatePoliklinikModel();
                    b.getTxtfld_poliklinikAdi().setText(null);
                    Helper.ShowMsg("Poliklinik ekleme başarılı...");

                } catch (IOException ex) {
                    java.util.logging.Logger.getLogger(BashekimGUI_action.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }

            }

        } else if (e.getSource() == b.getBtn_poliklinikSil()) {

            String Id = b.getTxtfld_poliklinikSec().getText();

            if (Id.length() == 0) {
                Helper.ShowMsg("fill");
            } else {

                try {
                    this.getPy().deletePoliklinik(Id);
                    b.updatePoliklinikModel();
                    b.getTxtfld_poliklinikSec().setText(null);
                    Helper.ShowMsg("Poliklinik silme işlemi başarılı...");

                } catch (IOException ex) {
                    Logger.getLogger(HastaGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        } else if (e.getSource() == b.getBtn_poliklinikDoktorEkle()) {
            int selectRow = b.getTable_poliklinikList().getSelectedRow();

            if (selectRow >= 0) {
                try {
                    String sPoliklinikId = b.getTable_poliklinikList().getModel().getValueAt(selectRow, 0).toString();
                    int selectPoliklinikId = Integer.parseInt(sPoliklinikId);

                    String sPoliklinikName = (String) b.getTable_poliklinikList().getModel().getValueAt(selectRow, 1);

                    Item doktorItem = (Item) b.getCbox_doktor().getSelectedItem();
                    int doktorId = doktorItem.getKey();

                    this.getBy().addWorker(doktorId, doktorItem.toString(), selectPoliklinikId, sPoliklinikName);
                    b.updateCalisanModel();
                    Helper.ShowMsg("Doktor atama işlemi başarılı...");

                } catch (IOException ex) {
                    Logger.getLogger(BashekimGUI_action.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                Helper.ShowMsg("Lütfen bir poliklinik seçiniz...");
            }

        } else if (e.getSource() == b.getBtn_cikis()) {
            GirisGUI g = new GirisGUI();
            g.setVisible(true);
            b.dispose();
        } else {

        }

    }
}
