/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim;

import DAO.*;
import java.io.*;
import java.util.List;
import model.Hasta;

/**
 *
 * @author Muzaffer
 */
public class HastaYonetim {

    private Hasta hasta;
    private List<Hasta> liste;
    private HastaDAO userDatabase;

    public HastaYonetim() {
    }

    public boolean checkUser(String tcNo, String sifre) throws IOException {
        Hasta newHasta = this.getHasta();
        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        return getUserDatabase().checkUser(newHasta);
    }
    
    public Hasta returnHasta(String tcNo, String sifre) throws IOException {
        Hasta newHasta = this.getHasta();
        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        return getUserDatabase().returnHasta(newHasta);
    }

    public void create(String tcNo, String sifre, String isimSoyisim) throws IOException {

        Hasta newHasta = this.getHasta();

        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        newHasta.setName(isimSoyisim);

        this.getUserDatabase().addUser(newHasta);

    }

    public Hasta getHasta() {
        if (this.hasta == null) {
            hasta = new Hasta();
        }
        return hasta;
    }

    public void setHasta(Hasta hasta) {
        this.hasta = hasta;
    }

    public List<Hasta> getListe() {

        return liste;
    }

    public void setListe(List<Hasta> liste) {
        this.liste = liste;
    }

    public HastaDAO getUserDatabase() {
        if (userDatabase == null) {
            this.userDatabase = new HastaDAO();
        }
        return userDatabase;
    }

    public void setUserDatabase(HastaDAO userDatabase) {
        this.userDatabase = userDatabase;
    }

}
