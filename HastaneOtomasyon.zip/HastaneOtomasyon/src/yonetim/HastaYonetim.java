/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package yonetim;

import DAO.*;
import java.io.*;
import java.util.List;
import model.Doktor;
import model.Hasta;

/**
 *
 * @author Muzaffer
 */
public class HastaYonetim {

    private Hasta hasta;
    private List<Hasta> liste;
    private HastaDAO userDatabase;
    private Doktor doktor;

    public HastaYonetim() {
    }

    public boolean checkUser(String tcNo, String sifre) throws IOException {
        Hasta newHasta = this.getHasta();
        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        return getUserDatabase().checkUser(newHasta);
    }
    
    public boolean checkUserK(String tcNo, String sifre) throws IOException {
        Hasta newHasta = this.getHasta();
        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        return getUserDatabase().checkUserK(newHasta);
    }

    public Hasta returnHasta(String tcNo, String sifre) throws IOException {
        Hasta newHasta = this.getHasta();
        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        return getUserDatabase().returnHasta(newHasta);
    }

    public void create(String tcNo, String sifre, String isimSoyisim) throws IOException {

        Hasta newHasta = this.getHasta();

        newHasta.setTcNo(tcNo);
        newHasta.setSifre(sifre);
        newHasta.setName(isimSoyisim);

        this.getUserDatabase().add(newHasta);

    }

    public void createRandevu(int doktorId, String doktorName, int hastaId, String hastaName,String date) {
        Hasta newHasta = this.getHasta();
        Doktor newDoktor = this.getDoktor();
        
        newDoktor.setId(doktorId);
        newDoktor.setName(doktorName);
        
        newHasta.setId(hastaId);
        newHasta.setName(hastaName);

        this.getUserDatabase().addRandevu(newDoktor,newHasta,date);
    }
    
    public void deleteRandevu(String Id) throws IOException {

        this.getUserDatabase().delete(Id);

    }

    public Hasta getHasta() {
        if (this.hasta == null) {
            hasta = new Hasta();
        }
        return hasta;
    }

    public void setHasta(Hasta hasta) {
        this.hasta = hasta;
    }

    public Doktor getDoktor() {
        if (this.doktor == null) {
            doktor = new Doktor();
        }
        return doktor;
    }

    public void setDoktor(Doktor doktor) {
        this.doktor = doktor;
    }

    public List<Hasta> getListe() {

        return liste;
    }

    public void setListe(List<Hasta> liste) {
        this.liste = liste;
    }

    public HastaDAO getUserDatabase() {
        if (userDatabase == null) {
            this.userDatabase = new HastaDAO();
        }
        return userDatabase;
    }

    public void setUserDatabase(HastaDAO userDatabase) {
        this.userDatabase = userDatabase;
    }

}
