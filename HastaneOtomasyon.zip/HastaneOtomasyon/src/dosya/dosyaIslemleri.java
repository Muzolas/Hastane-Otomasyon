/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dosya;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import model.BaseEntity;
import model.Calisan;
import model.DoktorCalismaSaati;
import model.Randevu;

/**
 *
 * @author Muzaffer
 */
public class dosyaIslemleri {

    public void add(BaseEntity be, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(be + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addWorker(int idDoktor, String nameDoktor, int idPoliklinik, String namePoliklinik, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                Calisan calisan = new Calisan();

                bufferedWriter.append(calisan.toString() + idDoktor + "," + nameDoktor + "," + idPoliklinik + "," + namePoliklinik + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addRandevu(int doktorId, String doktorName, int hastaId, String hastaName, String date, String str) {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                Randevu randevu = new Randevu();

                bufferedWriter.append(randevu.toString() + doktorId + "," + doktorName + "," + hastaId + "," + hastaName + "," + date + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addWhour(int Id, String nameDoktor, String wdate, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                DoktorCalismaSaati calismaSaat = new DoktorCalismaSaati();

                bufferedWriter.append(calismaSaat.toString() + Id + "," + nameDoktor + "," + wdate + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addPoliklinik(String veri, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(veri + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void delete(String str, String Id) throws IOException {

        try {
            List<String> yeniDosya;
            try ( FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str)) {
                try ( BufferedReader bR = new BufferedReader(fR)) {
                    String line = bR.readLine();
                    yeniDosya = new ArrayList<>();
                    while (line != null) {

                        String[] parts = line.split(",");

                        if (parts[0].equals(Id)) {
                            line = bR.readLine();
                        } else {
                            yeniDosya.add(line);
                            line = bR.readLine();
                        }

                    }
                    bR.close();
                }
                fR.close();
            }

            try ( BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str))) {
                for (String satir : yeniDosya) {
                    writer.write(satir + "\n");
                }
                writer.close();
            }
        } catch (IOException e) {
            System.err.println("Bir hata oluştu: " + e.getMessage());
        }

    }

}
