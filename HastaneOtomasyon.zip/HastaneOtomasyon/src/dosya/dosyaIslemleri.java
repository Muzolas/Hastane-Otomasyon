/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dosya;

import java.io.*;
import model.Calisan;
import model.DoktorCalismaSaati;

/**
 *
 * @author Muzaffer
 */
public class dosyaIslemleri {

    public void addUser(String veri, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(veri + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addWorker(int idDoktor, String nameDoktor, int idPoliklinik, String namePoliklinik, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                Calisan calisan = new Calisan();

                bufferedWriter.append(calisan.toString() + idDoktor + "," + nameDoktor + "," + idPoliklinik + "," + namePoliklinik + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addWhour(String nameDoktor, String wdate, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                DoktorCalismaSaati calismaSaat = new DoktorCalismaSaati();

                bufferedWriter.append(calismaSaat.toString() + nameDoktor + "," + wdate + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void addPoliklinik(String veri, String str) throws IOException {
        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str, true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(veri + "\n");
            }

        } catch (IOException e) {
        }
    }

    public void deleteUser(String str, String Id) throws IOException {

        int idInt = Integer.parseInt(Id);

        File oldFile = new File("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\User.txt");
        File newFile = new File("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\temp.txt");

        int lineNumber = 0;
        String currentLine;

        try {
            BufferedWriter buffw;
            BufferedReader buffr;
            try ( FileWriter filew = new FileWriter(newFile, false)) {
                buffw = new BufferedWriter(filew);
                FileReader filer;
                try ( PrintWriter printw = new PrintWriter(buffw)) {
                    filer = new FileReader(oldFile);
                    buffr = new BufferedReader(filer);
                    while ((currentLine = buffr.readLine()) != null) {
                        String[] currentParts = currentLine.split(",");
                        if (currentParts.length > 0) {

                            int currentId = Integer.parseInt(currentParts[0]);
                            if (currentId != idInt) {
                                printw.println(currentLine);
                            }
                        }
                        lineNumber++;
                    }
                    printw.flush();
                }
                filer.close();
            }
            buffr.close();
            buffw.close();

            oldFile.delete();
            newFile.renameTo(oldFile);
        } catch (IOException | NumberFormatException e) {

        }
    }
}

//    public boolean checkUser(String tcNo, String sifre, String str) throws IOException {
//        
//        boolean ctrl = false;
//
//        try {
//            FileReader fileReader = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\" + str);
//            BufferedReader bufferedReader = new BufferedReader(fileReader);
//
//            String line = bufferedReader.readLine();
//
//            while (line != null) {
//                String[] parts = line.split(",");
//                if (parts[1].equals(tcNo) && parts[2].equals(sifre)) {
//                    ctrl = true;
//                    Helper.ShowMsg("success");
//                    break;
//
//                }
//                line = bufferedReader.readLine();
//            }
//
//            if (line == null) {
//                Helper.ShowMsg("fail");
//                return false;
//            }
//
//        } catch (IOException e) {
//        }
//        return ctrl;
//    }

