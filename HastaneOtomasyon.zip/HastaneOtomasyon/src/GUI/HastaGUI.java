/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import DAO.BashekimDAO;
import DAO.HastaDAO;
import DAO.PoliklinikDAO;
import helper.Item;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import model.Calisan;
import model.Hasta;
import model.Poliklinik;
import model.Randevu;
import yonetim.action.HastaGUI_action;

/**
 *
 * @author Muzaffer
 */
public final class HastaGUI extends JFrame {

    private Hasta h;
    private JComboBox cbox_poliklinikSec;
    private JPanel pnl_pencere, pnl_randevu, pnl_randevuListe;
    private JTabbedPane w_tabpane;
    private JScrollPane scrlpane_doktor, scrlpane_calismaSaati, scrollPane_randevuListe;
    private JTable table_doktorList, table_calismaSaati, table_randevuListe;
    private JButton btn_cikis, btn_doktorSec, btn_randevuAl, btn_randevuSil;
    private JLabel lbl_msj, lbl_doktorList, lbl_calismaSaati, lbl_doktorSec, lbl_poliklinikSec, lbl_randevuAl;
    private JTextField txtfld_kullaniciId;
    private final DefaultTableModel doktorModel, randevuModel;
    private final Object[] doktorData, randevuData;

    public HastaGUI(Hasta h) throws IOException {

        this.h = h;

        HastaDAO hastaDAO = new HastaDAO();

        doktorModel = new DefaultTableModel();
        Object[] colDoktorName = new Object[2];

        colDoktorName[0] = "ID";
        colDoktorName[1] = "Ad Soyad";

        doktorModel.setColumnIdentifiers(colDoktorName);
        doktorData = new Object[2];

        randevuModel = new DefaultTableModel();
        Object[] colRandevuName = new Object[4];

        colRandevuName[0] = "ID";
        colRandevuName[1] = "Doktor Adı";
        colRandevuName[2] = "Hasta Adı";
        colRandevuName[3] = "Tarih ve Saat";

        randevuModel.setColumnIdentifiers(colRandevuName);
        randevuData = new Object[4];

        List<Randevu> randevuList = hastaDAO.getListRandevu(h.getId());

        for (int i = 0; i < randevuList.size(); i++) {

            randevuData[0] = randevuList.get(i).getId();
            randevuData[1] = randevuList.get(i).getDoktorName();
            randevuData[2] = randevuList.get(i).getHastaName();
            randevuData[3] = randevuList.get(i).getWdate();

            this.randevuModel.addRow(randevuData);

        }

        build();
    }

    public void updateRandevuModel() throws IOException {

        DefaultTableModel clearModel = randevuModel;
        clearModel.setRowCount(0);

        HastaDAO hastaDAO = new HastaDAO();

        List<Randevu> randevuList = hastaDAO.getListRandevu(h.getId());
        for (int i = 0; i < randevuList.size(); i++) {
            randevuData[0] = randevuList.get(i).getId();
            randevuData[1] = randevuList.get(i).getDoktorName();
            randevuData[2] = randevuList.get(i).getHastaName();
            randevuData[3] = randevuList.get(i).getWdate();

            this.randevuModel.addRow(randevuData);
        }

    }

    public Hasta getH() {
        return h;
    }

    public void setH(Hasta h) {
        this.h = h;
    }

    public JButton getBtn_randevuSil() {
        if (btn_randevuSil == null) {
            this.btn_randevuSil = new JButton("Sil");
            btn_randevuSil.setBounds(788, 5, 160, 30);
            this.btn_randevuSil.addActionListener(new HastaGUI_action(this));
        }
        return btn_randevuSil;
    }

    public void setBtn_randevuSil(JButton btn_randevuSil) {
        this.btn_randevuSil = btn_randevuSil;
    }

    public JTextField getTxtfld_kullaniciId() {
        if (txtfld_kullaniciId == null) {
            this.txtfld_kullaniciId = new JTextField();
            txtfld_kullaniciId.setBounds(620, 5, 160, 30);
        }
        return txtfld_kullaniciId;
    }

    public void setTxtfld_kullaniciId(JTextField txtfld_kullaniciId) {
        this.txtfld_kullaniciId = txtfld_kullaniciId;
    }

    public JPanel getPnl_randevuListe() {
        if (pnl_randevuListe == null) {
            this.pnl_randevuListe = new JPanel();
            pnl_randevuListe.setLayout(null);
            pnl_randevuListe.add(getScrollPane_randevuListe());
            pnl_randevuListe.add(getBtn_randevuSil());
            pnl_randevuListe.add(getTxtfld_kullaniciId());

        }
        return pnl_randevuListe;
    }

    public void setPnl_randevuListe(JPanel pnl_randevuListe) {
        this.pnl_randevuListe = pnl_randevuListe;
    }

    public JScrollPane getScrollPane_randevuListe() {
        if (scrollPane_randevuListe == null) {
            this.scrollPane_randevuListe = new JScrollPane();
            scrollPane_randevuListe.setBounds(5, 40, 945, 380);
            scrollPane_randevuListe.setViewportView(getTable_randevuListe());

        }
        return scrollPane_randevuListe;
    }

    public void setScrollPane_randevuListe(JScrollPane scrollPane_randevuListe) {
        this.scrollPane_randevuListe = scrollPane_randevuListe;
    }

    public JTable getTable_randevuListe() {
        if (table_randevuListe == null) {
            this.table_randevuListe = new JTable();
            table_randevuListe.setModel(randevuModel);
            

        }
        return table_randevuListe;
    }

    public void setTable_randevuListe(JTable table_randevuListe) {
        this.table_randevuListe = table_randevuListe;
    }

    public void build() throws IOException {
        add(getPnl_pencere());

        setSize(1000, 600);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public JPanel getPnl_pencere() throws IOException {
        if (pnl_pencere == null) {
            this.pnl_pencere = new JPanel();
            pnl_pencere.setLayout(null);

            pnl_pencere.add(getLbl_msj());
            pnl_pencere.add(getBtn_cikis());
            pnl_pencere.add(getW_tabpane());

        }
        return pnl_pencere;
    }

    public void setPnl_pencere(JPanel pnl_pencere) {
        this.pnl_pencere = pnl_pencere;
    }

    public JPanel getPnl_randevu() throws IOException {
        if (pnl_randevu == null) {
            this.pnl_randevu = new JPanel();
            pnl_randevu.setLayout(null);
            pnl_randevu.add(getBtn_doktorSec());
            pnl_randevu.add(getCbox_poliklinikSec());
            pnl_randevu.add(getLbl_calismaSaati());
            pnl_randevu.add(getLbl_doktorList());
            pnl_randevu.add(getLbl_doktorSec());
            pnl_randevu.add(getLbl_poliklinikSec());
            pnl_randevu.add(getScrlpane_calismaSaati());
            pnl_randevu.add(getScrlpane_doktor());
            pnl_randevu.add(getBtn_randevuAl());
            pnl_randevu.add(getLbl_randevuAl());

        }
        return pnl_randevu;
    }

    public JButton getBtn_randevuAl() {
        if (btn_randevuAl == null) {
            this.btn_randevuAl = new JButton("Al");
            btn_randevuAl.setBounds(370, 350, 195, 30);
            this.btn_randevuAl.addActionListener(new HastaGUI_action(this));
        }
        return btn_randevuAl;
    }

    public void setBtn_randevuAl(JButton btn_randevuAl) {
        this.btn_randevuAl = btn_randevuAl;
    }

    public JLabel getLbl_randevuAl() {
        if (lbl_randevuAl == null) {
            this.lbl_randevuAl = new JLabel("Randevu Al");
            lbl_randevuAl.setBounds(370, 320, 195, 30);
        }
        return lbl_randevuAl;
    }

    public void setLbl_randevuAl(JLabel lbl_randevuAl) {
        this.lbl_randevuAl = lbl_randevuAl;
    }

    public void setPnl_randevu(JPanel pnl_randevu) {
        this.pnl_randevu = pnl_randevu;
    }

    public JComboBox getCbox_poliklinikSec() throws IOException {
        if (cbox_poliklinikSec == null) {
            this.cbox_poliklinikSec = new JComboBox();

            cbox_poliklinikSec.setBounds(370, 40, 195, 30);

            PoliklinikDAO poliklinikDAO = new PoliklinikDAO();
            

            List<Poliklinik> dList = poliklinikDAO.getList();

            for (int i = 0; i < dList.size(); i++) {
                cbox_poliklinikSec.addItem(new Item(dList.get(i).getId(), dList.get(i).getName()));

            }

            cbox_poliklinikSec.addActionListener(e -> {

                if (cbox_poliklinikSec.getSelectedIndex() != 0) {

                    JComboBox c = (JComboBox) e.getSource();
                    Item item = (Item) c.getSelectedItem();
                    try {

                        DefaultTableModel clearModel = (DefaultTableModel) doktorModel;
                        clearModel.setRowCount(0);
                        
                        BashekimDAO bashekimDAO = new BashekimDAO();

                        List<Calisan> dListId = bashekimDAO.getListCalisanId(item.getKey());

                        for (int i = 0; i < dListId.size(); i++) {
                            doktorData[0] = dListId.get(i).getDoktorId();
                            doktorData[1] = dListId.get(i).getDoktorName();
                            doktorModel.addRow(doktorData);
                        }

                    } catch (IOException ex) {
                        Logger.getLogger(HastaGUI.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            });
        }

        return cbox_poliklinikSec;
    }

    public void setCbox_poliklinikSec(JComboBox cbox_poliklinikSec) {
        this.cbox_poliklinikSec = cbox_poliklinikSec;
    }

    public JTabbedPane getW_tabpane() throws IOException {
        if (w_tabpane == null) {
            this.w_tabpane = new JTabbedPane();
            w_tabpane.add("Randevu Sistemi", getPnl_randevu());
            w_tabpane.add("Randevularım", getPnl_randevuListe());
            w_tabpane.setBounds(10, 100, 960, 450);

        }
        return w_tabpane;
    }

    public void setW_tabpane(JTabbedPane w_tabpane) {
        this.w_tabpane = w_tabpane;
    }

    public JScrollPane getScrlpane_doktor() {
        if (scrlpane_doktor == null) {
            this.scrlpane_doktor = new JScrollPane();
            scrlpane_doktor.setViewportView(getTable_doktorList());
            scrlpane_doktor.setBounds(5, 40, 360, 380);
        }
        return scrlpane_doktor;
    }

    public void setScrlpane_doktor(JScrollPane scrlpane_doktor) {
        this.scrlpane_doktor = scrlpane_doktor;
    }

    public JScrollPane getScrlpane_calismaSaati() {
        if (scrlpane_calismaSaati == null) {
            this.scrlpane_calismaSaati = new JScrollPane();
            scrlpane_calismaSaati.setBounds(570, 40, 380, 380);
        }
        return scrlpane_calismaSaati;
    }

    public void setScrlpane_calismaSaati(JScrollPane scrlpane_calismaSaati) {
        this.scrlpane_calismaSaati = scrlpane_calismaSaati;
    }

    public JTable getTable_doktorList() {
        if (table_doktorList == null) {
            this.table_doktorList = new JTable();
            table_doktorList.setModel(doktorModel);
            table_doktorList.getColumnModel().getColumn(0).setPreferredWidth(3);
        }
        return table_doktorList;
    }

    public void setTable_doktorList(JTable table_doktorList) {
        this.table_doktorList = table_doktorList;
    }

    public JTable getTable_calismaSaati() {
        if (table_calismaSaati == null) {
            this.table_calismaSaati = new JTable();
        }
        return table_calismaSaati;
    }

    public void setTable_calismaSaati(JTable table_calismaSaati) {
        this.table_calismaSaati = table_calismaSaati;
    }

    public JButton getBtn_cikis() {
        if (btn_cikis == null) {

            this.btn_cikis = new JButton("Çıkış");
            btn_cikis.setBounds(800, 30, 150, 40);
            btn_cikis.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 20));
            this.btn_cikis.addActionListener(new HastaGUI_action(this));

        }
        return btn_cikis;
    }

    public void setBtn_cikis(JButton btn_cikis) {
        this.btn_cikis = btn_cikis;
    }

    public JButton getBtn_doktorSec() {
        if (btn_doktorSec == null) {
            this.btn_doktorSec = new JButton("Seç");
            btn_doktorSec.setBounds(370, 200, 195, 30);
            this.btn_doktorSec.addActionListener(new HastaGUI_action(this));
        }
        return btn_doktorSec;
    }

    public void setBtn_doktorSec(JButton btn_doktorSec) {
        this.btn_doktorSec = btn_doktorSec;
    }

    public JLabel getLbl_msj() {
        if (lbl_msj == null) {

            this.lbl_msj = new JLabel("Hoşgeldiniz Sayın " + h.getName());
            lbl_msj.setBounds(20, 30, 700, 40);
            lbl_msj.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 30));
        }
        return lbl_msj;
    }

    public void setLbl_msj(JLabel lbl_msj) {
        this.lbl_msj = lbl_msj;
    }

    public JLabel getLbl_doktorList() {
        if (lbl_doktorList == null) {
            this.lbl_doktorList = new JLabel("Doktor Listesi");
            lbl_doktorList.setBounds(10, 10, 100, 20);
        }
        return lbl_doktorList;
    }

    public void setLbl_doktorList(JLabel lbl_doktorList) {
        this.lbl_doktorList = lbl_doktorList;
    }

    public JLabel getLbl_calismaSaati() {
        if (lbl_calismaSaati == null) {
            this.lbl_calismaSaati = new JLabel("Çalışma Saatleri");
            lbl_calismaSaati.setBounds(570, 10, 100, 20);
        }
        return lbl_calismaSaati;
    }

    public void setLbl_calismaSaati(JLabel lbl_calismaSaati) {
        this.lbl_calismaSaati = lbl_calismaSaati;
    }

    public JLabel getLbl_doktorSec() {
        if (lbl_doktorSec == null) {
            this.lbl_doktorSec = new JLabel("Doktor Seç");
            lbl_doktorSec.setBounds(370, 170, 195, 30);
        }
        return lbl_doktorSec;
    }

    public void setLbl_doktorSec(JLabel lbl_doktorSec) {
        this.lbl_doktorSec = lbl_doktorSec;
    }

    public JLabel getLbl_poliklinikSec() {
        if (lbl_poliklinikSec == null) {
            this.lbl_poliklinikSec = new JLabel("Poliklinik Seç");
            lbl_poliklinikSec.setBounds(370, 10, 100, 20);
        }
        return lbl_poliklinikSec;
    }

    public void setLbl_poliklinikSec(JLabel lbl_poliklinikSec) {
        this.lbl_poliklinikSec = lbl_poliklinikSec;
    }

}
