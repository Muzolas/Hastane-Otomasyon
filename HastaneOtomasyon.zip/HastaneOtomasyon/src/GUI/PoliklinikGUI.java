/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import javax.swing.*;

/**
 *
 * @author Muzaffer
 */
public class PoliklinikGUI extends JFrame {

    private JPanel pnl_pencere;
    private JLabel lbl_poliklinikAdi;
    private JTextField txtfld_poliklinikAdi;
    private JButton btn_guncelle;

    public PoliklinikGUI() {

        build();
    }

    public void build() {
        add(getPnl_pencere());
        setSize(300, 150);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JPanel getPnl_pencere() {
        if(pnl_pencere == null){
            this.pnl_pencere = new JPanel();
            pnl_pencere.setLayout(null);
            pnl_pencere.add(getLbl_poliklinikAdi());
            pnl_pencere.add(getTxtfld_poliklinikAdi());
            pnl_pencere.add(getBtn_guncelle());
        }
        return pnl_pencere;
    }
    
    
    
    public void setPnl_pencere(JPanel pnl_pencere) {
        this.pnl_pencere = pnl_pencere;
    }
    
    public JTextField getTxtfld_poliklinikAdi() {
        if(txtfld_poliklinikAdi == null){
            this.txtfld_poliklinikAdi = new JTextField();
            txtfld_poliklinikAdi.setBounds(10, 30, 265, 30);
        }
        return txtfld_poliklinikAdi;
    }

    public void setTxtfld_poliklinikAdi(JTextField txtfld_poliklinikAdi) {
        this.txtfld_poliklinikAdi = txtfld_poliklinikAdi;
    }

    public JLabel getLbl_poliklinikAdi() {
        if(lbl_poliklinikAdi == null){
            this.lbl_poliklinikAdi = new JLabel("Poliklinik Adı");
            lbl_poliklinikAdi.setBounds(10, 0, 265, 30);
        }
        return lbl_poliklinikAdi;
    }

    public void setLbl_poliklinikAdi(JLabel lbl_poliklinikAdi) {
        this.lbl_poliklinikAdi = lbl_poliklinikAdi;
    }

    public JButton getBtn_guncelle() {
        if(btn_guncelle == null){
            this.btn_guncelle = new JButton("Güncelle");
            btn_guncelle.setBounds(10, 65, 265, 30);
        }
        return btn_guncelle;
    }

    public void setBtn_guncelle(JButton btn_guncelle) {
        this.btn_guncelle = btn_guncelle;
    }

}
