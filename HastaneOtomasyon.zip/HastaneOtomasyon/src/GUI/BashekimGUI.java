/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import DAO.BashekimDAO;
import DAO.DoktorDAO;
import DAO.PoliklinikDAO;
import helper.Item;
import java.awt.Font;

import java.io.IOException;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import model.Calisan;
import model.Doktor;
import model.Poliklinik;
import yonetim.action.BashekimGUI_action;

/**
 *
 * @author Muzaffer
 */
public final class BashekimGUI extends JFrame {

    private JComboBox cbox_doktor;
    private JPanel pnl_pencere, pnl_doktorYonetim, pnl_poliklinikYonetim;
    private JTabbedPane w_tabpane;
    private JScrollPane w_scrollpane, scrlpane_poliklinik, scrlpane_poliklinikDoktor;
    private JTable table_doktorList, table_poliklinikList, table_poliklinikDoktor;
    private JButton btn_doktorEkle, btn_doktorSil, btn_cikis, btn_poliklinikEkle, btn_poliklinikDoktorEkle, btn_poliklinikSec;
    private JLabel lbl_msj, lbl_doktorAdsoyad, lbl_doktorTC, lbl_doktorSifre, lbl_kullanıcıID, lbl_poliklinikAdi, lbl_poliklinikSec;
    private JTextField txtfld_doktorAdsoyad, txtfld_doktorTC, txtfld_doktorSifre, txtfld_kullanıcıID, txtfld_poliklinikAdi;

    private final DefaultTableModel doktorModel, poliklinikModel, calisanModel;

    public Object[] doktorData, poliklinikData, calisanData;

    public BashekimGUI() throws IOException {

        DoktorDAO doktorDAO = new DoktorDAO();

        doktorModel = new DefaultTableModel();
        Object[] colDoktorName = new Object[4];

        colDoktorName[0] = "ID";
        colDoktorName[1] = "T.C. Numarası";
        colDoktorName[2] = "Şifre";
        colDoktorName[3] = "Ad Soyad";

        doktorModel.setColumnIdentifiers(colDoktorName);
        doktorData = new Object[4];

        List<Doktor> dList = doktorDAO.getList();

        for (int i = 0; i < dList.size(); i++) {

            doktorData[0] = dList.get(i).getId();
            doktorData[1] = dList.get(i).getTcNo();
            doktorData[2] = dList.get(i).getSifre();
            doktorData[3] = dList.get(i).getName();

            this.doktorModel.addRow(doktorData);

        }

        PoliklinikDAO poliklinikDAO = new PoliklinikDAO();

        poliklinikModel = new DefaultTableModel();
        Object[] colPoliklinikName = new Object[2];

        colPoliklinikName[0] = "ID";
        colPoliklinikName[1] = "Poliklinik Adı";

        poliklinikModel.setColumnIdentifiers(colPoliklinikName);
        poliklinikData = new Object[2];

        List<Poliklinik> pList = poliklinikDAO.getList();

        for (int i = 0; i < pList.size(); i++) {
            poliklinikData[0] = pList.get(i).getId();
            poliklinikData[1] = pList.get(i).getName();

            this.poliklinikModel.addRow(poliklinikData);

        }

        BashekimDAO bashekimDAO = new BashekimDAO();

        calisanModel = new DefaultTableModel();
        Object[] colCalisanName = new Object[3];
        colCalisanName[0] = "Id";
        colCalisanName[1] = "Doktor Adı";
        colCalisanName[2] = "Poliklinik Adı";

        calisanModel.setColumnIdentifiers(colCalisanName);
        calisanData = new Object[3];

        List<Calisan> cList = bashekimDAO.getListCalisan();

        for (int i = 0; i < cList.size(); i++) {

            calisanData[0] = cList.get(i).getId();
            calisanData[1] = cList.get(i).getDoktorName();
            calisanData[2] = cList.get(i).getPoliklinikName();
            this.calisanModel.addRow(calisanData);

        }

        build();
    }

    public void updatePoliklinikModel() throws IOException {

        DefaultTableModel clearModel = poliklinikModel;
        clearModel.setRowCount(0);
        PoliklinikDAO poliklinikDAO = new PoliklinikDAO();

        List<Poliklinik> pList = poliklinikDAO.getList();
        for (int i = 0; i < pList.size(); i++) {
            poliklinikData[0] = pList.get(i).getId();
            poliklinikData[1] = pList.get(i).getName();

            this.poliklinikModel.addRow(poliklinikData);
        }

    }

    public void updateDoktorModel() throws IOException {

        DefaultTableModel clearModel = doktorModel;
        clearModel.setRowCount(0);
        DoktorDAO doktorDAO = new DoktorDAO();

        List<Doktor> dList = doktorDAO.getList();
        for (int i = 0; i < dList.size(); i++) {
            doktorData[0] = dList.get(i).getId();
            doktorData[1] = dList.get(i).getTcNo();
            doktorData[2] = dList.get(i).getSifre();
            doktorData[3] = dList.get(i).getName();

            this.doktorModel.addRow(doktorData);

        }

    }

     public void updateCalisanModel() throws IOException {

        DefaultTableModel clearModel = calisanModel;
        clearModel.setRowCount(0);
        BashekimDAO bashekimDAO = new BashekimDAO();

        List<Calisan> cList = bashekimDAO.getListCalisan();
        for (int i = 0; i < cList.size(); i++) {
            
            calisanData[0] = cList.get(i).getId();
            calisanData[1] = cList.get(i).getDoktorName();
            calisanData[2] = cList.get(i).getPoliklinikName();
            

            this.calisanModel.addRow(calisanData);

        }

    }
    public void build() throws IOException {
        add(getPnl_pencere());
        setBounds(450, 250, 1000, 600);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public JPanel getPnl_pencere() throws IOException {
        if (pnl_pencere == null) {
            this.pnl_pencere = new JPanel();
            pnl_pencere.setLayout(null);
            pnl_pencere.add(getLbl_msj());
            pnl_pencere.add(getBtn_cikis());
            pnl_pencere.add(getW_tabpane());

        }
        return pnl_pencere;
    }

    public void setPnl_pencere(JPanel pnl_pencere) {
        this.pnl_pencere = pnl_pencere;
    }

    public JPanel getPnl_doktorYonetim() {
        if (pnl_doktorYonetim == null) {
            this.pnl_doktorYonetim = new JPanel();
            pnl_doktorYonetim.setLayout(null);

            pnl_doktorYonetim.add(getW_scrollpane());
            pnl_doktorYonetim.add(getLbl_doktorAdsoyad());
            pnl_doktorYonetim.add(getTxtfld_doktorAdsoyad());
            pnl_doktorYonetim.add(getLbl_doktorTC());
            pnl_doktorYonetim.add(getTxtfld_doktorTC());
            pnl_doktorYonetim.add(getLbl_doktorSifre());
            pnl_doktorYonetim.add(getTxtfld_doktorSifre());
            pnl_doktorYonetim.add(getBtn_doktorEkle());
            pnl_doktorYonetim.add(getLbl_kullanıcıID());
            pnl_doktorYonetim.add(getTxtfld_kullanıcıID());
            pnl_doktorYonetim.add(getBtn_doktorSil());
        }
        return pnl_doktorYonetim;
    }

    public void setPnl_doktorYonetim(JPanel pnl_doktorYonetim) {
        this.pnl_doktorYonetim = pnl_doktorYonetim;

    }

    public JPanel getPnl_poliklinikYonetim() throws IOException {
        if (pnl_poliklinikYonetim == null) {
            this.pnl_poliklinikYonetim = new JPanel();
            pnl_poliklinikYonetim.setLayout(null);

            pnl_poliklinikYonetim.add(getScrlpane_poliklinik());
            pnl_poliklinikYonetim.add(getScrlpane_poliklinikDoktor());

            pnl_poliklinikYonetim.add(getLbl_poliklinikAdi());
            pnl_poliklinikYonetim.add(getTxtfld_poliklinikAdi());
            pnl_poliklinikYonetim.add(getBtn_poliklinikEkle());
            pnl_poliklinikYonetim.add(getLbl_poliklinikSec());
            pnl_poliklinikYonetim.add(getBtn_poliklinikSec());
            pnl_poliklinikYonetim.add(getCbox_doktor());
            pnl_poliklinikYonetim.add(getBtn_poliklinikDoktorEkle());

        }
        return pnl_poliklinikYonetim;
    }

    public void setPnl_klinikYonetim(JPanel pnl_klinikYonetim) {
        this.pnl_poliklinikYonetim = pnl_klinikYonetim;
    }

    public JComboBox getCbox_doktor() throws IOException {
        if (cbox_doktor == null) {
            this.cbox_doktor = new JComboBox();
            cbox_doktor.setBounds(390, 300, 175, 30);
            DoktorDAO doktorDAO = new DoktorDAO();

            List<Doktor> dList = doktorDAO.getList();

            for (int i = 0; i < dList.size(); i++) {
                cbox_doktor.addItem(new Item(dList.get(i).getId(), dList.get(i).getName()));

            }
            cbox_doktor.addActionListener(e -> {
                JComboBox c = (JComboBox) e.getSource();
                Item item = (Item) c.getSelectedItem();

            });
        }
        return cbox_doktor;
    }

    public void setCbox_doktor(JComboBox cbox_doktor) {
        this.cbox_doktor = cbox_doktor;
    }

    public JScrollPane getScrlpane_poliklinik() {
        if (scrlpane_poliklinik == null) {
            this.scrlpane_poliklinik = new JScrollPane();
            scrlpane_poliklinik.setViewportView(getTable_poliklinikList());
            scrlpane_poliklinik.setBounds(5, 5, 380, 415);

        }
        return scrlpane_poliklinik;
    }

    public void setScrlpane_poliklinik(JScrollPane scrlpane_poliklinik) {
        this.scrlpane_poliklinik = scrlpane_poliklinik;
    }

    public JScrollPane getScrlpane_poliklinikDoktor() {
        if (scrlpane_poliklinikDoktor == null) {
            this.scrlpane_poliklinikDoktor = new JScrollPane();
            scrlpane_poliklinikDoktor.setViewportView(getTable_poliklinikDoktor());
            scrlpane_poliklinikDoktor.setBounds(570, 5, 380, 415);
        }
        return scrlpane_poliklinikDoktor;
    }

    public void setScrlpane_poliklinikDoktor(JScrollPane scrlpane_poliklinikDoktor) {
        this.scrlpane_poliklinikDoktor = scrlpane_poliklinikDoktor;
    }

    public JTable getTable_poliklinikList() {
        if (table_poliklinikList == null) {
            this.table_poliklinikList = new JTable();
            table_poliklinikList.setModel(poliklinikModel);

        }
        return table_poliklinikList;
    }

    public void setTable_poliklinikList(JTable table_poliklinikList) {
        this.table_poliklinikList = table_poliklinikList;
    }

    public JTable getTable_poliklinikDoktor() {
        if (table_poliklinikDoktor == null) {
            this.table_poliklinikDoktor = new JTable();
            table_poliklinikDoktor.setModel(calisanModel);
        }
        return table_poliklinikDoktor;
    }

    public void setTable_poliklinikDoktor(JTable table_poliklinikDoktor) {

        this.table_poliklinikDoktor = table_poliklinikDoktor;
    }

    public JButton getBtn_poliklinikEkle() {
        if (btn_poliklinikEkle == null) {
            this.btn_poliklinikEkle = new JButton("Poliklinik Ekle");
            btn_poliklinikEkle.setBounds(390, 105, 175, 30);
            this.btn_poliklinikEkle.addActionListener(new BashekimGUI_action(this));
        }
        return btn_poliklinikEkle;
    }

    public void setBtn_poliklinikEkle(JButton btn_poliklinikEkle) {
        this.btn_poliklinikEkle = btn_poliklinikEkle;
    }

    public JButton getBtn_poliklinikDoktorEkle() {
        if (btn_poliklinikDoktorEkle == null) {
            this.btn_poliklinikDoktorEkle = new JButton("Doktor Ekle");
            btn_poliklinikDoktorEkle.setBounds(390, 340, 175, 30);
            this.btn_poliklinikDoktorEkle.addActionListener(new BashekimGUI_action(this));
        }
        return btn_poliklinikDoktorEkle;
    }

    public void setBtn_poliklinikDoktorEkle(JButton btn_poliklinikDoktorEkle) {
        this.btn_poliklinikDoktorEkle = btn_poliklinikDoktorEkle;
    }

    public JButton getBtn_poliklinikSec() {
        if (btn_poliklinikSec == null) {
            this.btn_poliklinikSec = new JButton("Poliklinik Seç");
            btn_poliklinikSec.setBounds(390, 210, 170, 30);
            this.btn_poliklinikSec.addActionListener(new BashekimGUI_action(this));
        }
        return btn_poliklinikSec;
    }

    public void setBtn_poliklinikSec(JButton btn_poliklinikSec) {
        this.btn_poliklinikSec = btn_poliklinikSec;
    }

    public JLabel getLbl_poliklinikAdi() {
        if (lbl_poliklinikAdi == null) {
            this.lbl_poliklinikAdi = new JLabel("Poliklinik Adı");
            lbl_poliklinikAdi.setBounds(390, 40, 100, 30);
        }
        return lbl_poliklinikAdi;
    }

    public void setLbl_poliklinikAdi(JLabel lbl_poliklinikAdi) {
        this.lbl_poliklinikAdi = lbl_poliklinikAdi;
    }

    public JLabel getLbl_poliklinikSec() {
        if (lbl_poliklinikSec == null) {
            this.lbl_poliklinikSec = new JLabel("Poliklinikler");
            lbl_poliklinikSec.setBounds(390, 180, 170, 30);
        }
        return lbl_poliklinikSec;
    }

    public void setLbl_poliklinikSec(JLabel lbl_poliklinikSec) {
        this.lbl_poliklinikSec = lbl_poliklinikSec;
    }

    public JTextField getTxtfld_poliklinikAdi() {
        if (txtfld_poliklinikAdi == null) {
            this.txtfld_poliklinikAdi = new JTextField();
            txtfld_poliklinikAdi.setBounds(390, 65, 170, 30);
        }
        return txtfld_poliklinikAdi;
    }

    public void setTxtfld_poliklinikAdi(JTextField txtfld_poliklinikAdi) {
        this.txtfld_poliklinikAdi = txtfld_poliklinikAdi;
    }

    public JTabbedPane getW_tabpane() throws IOException {
        if (w_tabpane == null) {
            this.w_tabpane = new JTabbedPane();
            w_tabpane.setBounds(10, 100, 960, 450);
            w_tabpane.add("Doktor Yönetim", getPnl_doktorYonetim());
            w_tabpane.add("Poliklinik Yönetim", getPnl_poliklinikYonetim());
        }
        return w_tabpane;
    }

    public void setW_tabpane(JTabbedPane w_tabpane) {
        this.w_tabpane = w_tabpane;
    }

    public JScrollPane getW_scrollpane() {
        if (w_scrollpane == null) {
            this.w_scrollpane = new JScrollPane();
            w_scrollpane.setViewportView(getTable_doktorList());
            w_scrollpane.setBounds(5, 5, 710, 415);

        }
        return w_scrollpane;
    }

    public void setW_scrollpane(JScrollPane w_scrollpane) {
        this.w_scrollpane = w_scrollpane;
    }

    public JTable getTable_doktorList() {
        if (table_doktorList == null) {
            this.table_doktorList = new JTable();
            table_doktorList.setModel(doktorModel);
            table_doktorList.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                @Override
                public void valueChanged(ListSelectionEvent e) {
                    txtfld_kullanıcıID.setText(table_doktorList.getValueAt(table_doktorList.getSelectedRow(), 0).toString());
                }
            });
        }
        return table_doktorList;
    }

    public void setTable_doktorList(JTable table_doktorList) {
        this.table_doktorList = table_doktorList;
    }

    public JButton getBtn_doktorEkle() {
        if (btn_doktorEkle == null) {
            this.btn_doktorEkle = new JButton("Ekle");
            btn_doktorEkle.setBounds(725, 220, 220, 40);
            btn_doktorEkle.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 20));
            this.btn_doktorEkle.addActionListener(new BashekimGUI_action(this));
        }
        return btn_doktorEkle;
    }

    public void setBtn_doktorEkle(JButton btn_doktorEkle) {
        this.btn_doktorEkle = btn_doktorEkle;
    }

    public JButton getBtn_doktorSil() {
        if (btn_doktorSil == null) {
            this.btn_doktorSil = new JButton("Sil");
            btn_doktorSil.setBounds(725, 350, 220, 40);
            btn_doktorSil.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 20));
            this.btn_doktorSil.addActionListener(new BashekimGUI_action(this));
        }
        return btn_doktorSil;
    }

    public void setBtn_doktorSil(JButton btn_doktorSil) {
        this.btn_doktorSil = btn_doktorSil;
    }

    public JButton getBtn_cikis() {
        if (btn_cikis == null) {
            this.btn_cikis = new JButton("Çıkış");
            btn_cikis.setBounds(800, 30, 150, 40);
            btn_cikis.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 20));
            this.btn_cikis.addActionListener(new BashekimGUI_action(this));
        }
        return btn_cikis;
    }

    public void setBtn_cikis(JButton btn_cikis) {
        this.btn_cikis = btn_cikis;
    }

    public JLabel getLbl_msj() {
        if (lbl_msj == null) {
            this.lbl_msj = new JLabel("Hoşgeldiniz...");
            lbl_msj.setBounds(20, 30, 300, 40);
            lbl_msj.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 30));
        }
        return lbl_msj;
    }

    public void setLbl_msj(JLabel lbl_msj) {
        this.lbl_msj = lbl_msj;
    }

    public JLabel getLbl_doktorAdsoyad() {
        if (lbl_doktorAdsoyad == null) {
            this.lbl_doktorAdsoyad = new JLabel("Ad Soyad");
            lbl_doktorAdsoyad.setBounds(725, 25, 100, 20);
            lbl_doktorAdsoyad.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_doktorAdsoyad;
    }

    public void setLbl_doktorAdsoyad(JLabel lbl_doktorAdsoyad) {
        this.lbl_doktorAdsoyad = lbl_doktorAdsoyad;
    }

    public JLabel getLbl_doktorTC() {
        if (lbl_doktorTC == null) {
            this.lbl_doktorTC = new JLabel("T.C. No");
            lbl_doktorTC.setBounds(725, 80, 100, 30);
            lbl_doktorTC.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_doktorTC;
    }

    public void setLbl_doktorTC(JLabel lbl_doktorTC) {
        this.lbl_doktorTC = lbl_doktorTC;
    }

    public JLabel getLbl_doktorSifre() {
        if (lbl_doktorSifre == null) {
            this.lbl_doktorSifre = new JLabel("Şifre");
            lbl_doktorSifre.setBounds(725, 140, 220, 30);
            lbl_doktorSifre.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_doktorSifre;
    }

    public void setLbl_doktorSifre(JLabel lbl_doktorSifre) {
        this.lbl_doktorSifre = lbl_doktorSifre;
    }

    public JLabel getLbl_kullanıcıID() {
        if (lbl_kullanıcıID == null) {
            this.lbl_kullanıcıID = new JLabel("Kullanıcı ID");
            lbl_kullanıcıID.setBounds(725, 270, 100, 30);
            lbl_kullanıcıID.setFont(new Font("YU Gothic UI Semibold", Font.PLAIN, 15));
        }
        return lbl_kullanıcıID;
    }

    public void setLbl_kullanıcıID(JLabel lbl_kullanıcıID) {
        this.lbl_kullanıcıID = lbl_kullanıcıID;
    }

    public JTextField getTxtfld_doktorAdsoyad() {
        if (txtfld_doktorAdsoyad == null) {
            this.txtfld_doktorAdsoyad = new JTextField();
            txtfld_doktorAdsoyad.setBounds(725, 50, 220, 30);
        }
        return txtfld_doktorAdsoyad;
    }

    public void setTxtfld_doktorAdsoyad(JTextField txtfld_doktorAdsoyad) {
        this.txtfld_doktorAdsoyad = txtfld_doktorAdsoyad;
    }

    public JTextField getTxtfld_doktorTC() {
        if (txtfld_doktorTC == null) {
            this.txtfld_doktorTC = new JTextField();
            txtfld_doktorTC.setBounds(725, 110, 220, 30);
        }
        return txtfld_doktorTC;
    }

    public void setTxtfld_doktorTC(JTextField txtfld_doktorTC) {
        this.txtfld_doktorTC = txtfld_doktorTC;
    }

    public JTextField getTxtfld_doktorSifre() {
        if (txtfld_doktorSifre == null) {
            this.txtfld_doktorSifre = new JTextField();
            txtfld_doktorSifre.setBounds(725, 170, 220, 30);
        }
        return txtfld_doktorSifre;
    }

    public void setTxtfld_doktorSifre(JTextField txtfld_doktorSifre) {
        this.txtfld_doktorSifre = txtfld_doktorSifre;
    }

    public JTextField getTxtfld_kullanıcıID() {
        if (txtfld_kullanıcıID == null) {
            this.txtfld_kullanıcıID = new JTextField();
            txtfld_kullanıcıID.setBounds(725, 300, 220, 30);
        }
        return txtfld_kullanıcıID;
    }

    public void setTxtfld_kullanıcıID(JTextField txtfld_kullanıcıID) {
        this.txtfld_kullanıcıID = txtfld_kullanıcıID;
    }

}
