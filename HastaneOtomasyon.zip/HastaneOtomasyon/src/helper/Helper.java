/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helper;

import javax.swing.JOptionPane;

/**
 *
 * @author Muzaffer
 */
public class Helper {

    public static void ShowMsg(String str) {
        String msg;

        switch (str) {
            case "fill":
                msg = "Lütfen tüm alanları doldurunuz...";
                break;
            case "fail":
                msg = "Kullanıcı adı veya şifre yanlış...";
                break;
            case "success":
                msg = "Giriş başarıyla yapıldı...";
                break;
            default:
                msg = str;
        }
        JOptionPane.showMessageDialog(null, msg, "Mesaj", JOptionPane.INFORMATION_MESSAGE);
    }

    
}
