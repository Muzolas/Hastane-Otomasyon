/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import dosya.dosyaIslemleri;
import helper.Helper;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import model.Doktor;

/**
 *
 * @author Muzaffer
 */
public class DoktorDAO {

    dosyaIslemleri dosya = new dosyaIslemleri();
    private List<Doktor> doktorList = new ArrayList<>();

    public void addUser(Doktor d) throws IOException {

        dosya.addUser(d.toString(), "User.txt");
    }

    public void addWhour(Doktor d, String wdate) throws IOException {
        dosya.addWhour(d.getName(), wdate, "CalismaSaat.txt");
    }

    public List<Doktor> getList() throws IOException {
        FileReader fR = new FileReader("C:\\Users\\Muzaffer\\Desktop\\Yeni klasör\\HastaneOtomasyon\\src\\dosya\\User.txt");
        BufferedReader bR = new BufferedReader(fR);

        String line = bR.readLine();
        while (line != null) {
            String[] parts = line.split(",");
            if ("Doktor".equals(parts[4])) {
                Doktor d = new Doktor(Integer.parseInt(parts[0]), parts[1], parts[2], parts[3], parts[4]);
                doktorList.add(d);
            }

            line = bR.readLine();
        }
        return this.doktorList;
    }

    public boolean checkUser(Doktor newDoktor) throws IOException {
        List<Doktor> list = this.getList();
        boolean check = false;

        for (Doktor d : list) {
            if (d.equals(newDoktor)) {
                Helper.ShowMsg("success");
                check = true;
            }
        }
        return check;
    }

    public void deleteUser(String Id) throws IOException {
        dosya.deleteUser("User.txt", Id);
    }
}
